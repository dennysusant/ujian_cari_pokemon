from flask import Flask, abort, jsonify, render_template,url_for, request,send_from_directory,redirect
import plotly
import plotly.graph_objects as go 
import chart_studio.plotly as py 
import numpy as np 
import pandas as pd 
import json
import requests 

app=Flask(__name__)


@app.route('/')
def home():
    return render_template('poke.html')

@app.route('/Cari', methods=['GET','POST'])
def Cari():
    body=request.form
    body1=body['pokemon']
    body1=body1.lower()
    poke='https://pokeapi.co/api/v2/pokemon/{}'.format(body1)
    data=requests.get(url=str(poke))
    if data.status_code==200:
        data=data.json()
        gambar=data["sprites"]['front_default']
        nama=data['name']
        nama=nama.capitalize()
        id=data['id']
        height=data['height']
        weight=data['weight']
        return render_template('caripoke.html',x=gambar,y=nama,z=id,a=height,b=weight)
    else:
        return render_template('notfound.html')
        



if __name__=='__main__':
    app.run(debug=True)





